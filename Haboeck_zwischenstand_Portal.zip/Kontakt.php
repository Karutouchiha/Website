<!-------------------
-Name: Sarah Haböck -
-Datum: 04.06.2021  -
--------------------->
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Schüler: Homepage</title>
    <link href="Design.css" type="text/css" rel="stylesheet">
</head>
<body>

</body>
</html>
